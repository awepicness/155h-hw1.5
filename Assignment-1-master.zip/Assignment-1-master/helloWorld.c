#include <stdlib.h>

/**
* This program will display my and my partner's names.
*
* @author Martin Nguyen
* @date 9/7/2018
*/

int main(int argc, char **argv) {

  printf("Martin Nguyen and Ethan Weber");

  return 0;
}
